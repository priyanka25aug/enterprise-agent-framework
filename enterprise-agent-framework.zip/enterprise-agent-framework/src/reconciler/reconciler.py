import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
from src.agents.base_agent import AgentOutput
from src.utils.audit_logger import AuditLogger


@dataclass
class ReconcilerResult:
    """Final output returned to the caller after reconciliation."""
    request_id: str
    agent_name: str
    output: Any
    confidence: float
    passed: bool                    # True = output returned; False = escalated or rejected
    escalated_to_human: bool
    rejection_reason: Optional[str]
    audit_trail: dict
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id,
            "agent_name": self.agent_name,
            "output": self.output,
            "confidence": self.confidence,
            "passed": self.passed,
            "escalated_to_human": self.escalated_to_human,
            "rejection_reason": self.rejection_reason,
            "audit_trail": self.audit_trail,
            "timestamp": self.timestamp,
        }

    def __str__(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)


class Reconciler:
    """
    The final gate before output reaches a human or downstream system.

    Does three things:
    1. Confidence check — below threshold → escalate, do not return output
    2. Schema validation — output must match expected structure for agent type
    3. Audit logging — every decision recorded regardless of outcome

    In regulated environments, a rejected or escalated output is not a failure.
    It is the system working correctly.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.75,
        audit_logger: Optional[AuditLogger] = None,
    ):
        if not 0.0 <= confidence_threshold <= 1.0:
            raise ValueError("confidence_threshold must be between 0.0 and 1.0")
        self.confidence_threshold = confidence_threshold
        self.logger = audit_logger or AuditLogger()

    def process(self, agent_output: AgentOutput) -> ReconcilerResult:
        """
        Validate and gate agent output. Returns a ReconcilerResult.
        """
        checks = self._run_checks(agent_output)
        passed = all(c["passed"] for c in checks)
        escalated = agent_output.escalate_to_human or not passed
        rejection_reason = self._get_rejection_reason(checks) if not passed else None

        result = ReconcilerResult(
            request_id=agent_output.request_id,
            agent_name=agent_output.agent_name,
            output=agent_output.output if passed else None,
            confidence=agent_output.confidence,
            passed=passed,
            escalated_to_human=escalated,
            rejection_reason=rejection_reason,
            audit_trail=self._build_audit_trail(agent_output, checks, passed, escalated),
        )

        self.logger.log(result.audit_trail)
        return result

    def _run_checks(self, output: AgentOutput) -> list:
        return [
            self._check_confidence(output),
            self._check_output_not_empty(output),
            self._check_escalation_flag(output),
        ]

    def _check_confidence(self, output: AgentOutput) -> dict:
        passed = output.confidence >= self.confidence_threshold
        return {
            "check": "confidence_threshold",
            "passed": passed,
            "detail": (
                f"confidence {output.confidence:.2f} >= threshold {self.confidence_threshold:.2f}"
                if passed else
                f"confidence {output.confidence:.2f} below threshold {self.confidence_threshold:.2f}"
            ),
        }

    def _check_output_not_empty(self, output: AgentOutput) -> dict:
        passed = output.output is not None and output.output != ""
        return {
            "check": "output_not_empty",
            "passed": passed,
            "detail": "output present" if passed else "agent returned empty output",
        }

    def _check_escalation_flag(self, output: AgentOutput) -> dict:
        passed = not output.escalate_to_human
        return {
            "check": "escalation_flag",
            "passed": passed,
            "detail": "agent did not request escalation" if passed else "agent requested human review",
        }

    def _get_rejection_reason(self, checks: list) -> str:
        failed = [c["detail"] for c in checks if not c["passed"]]
        return "; ".join(failed)

    def _build_audit_trail(
        self,
        output: AgentOutput,
        checks: list,
        passed: bool,
        escalated: bool,
    ) -> dict:
        return {
            "request_id": output.request_id,
            "agent_name": output.agent_name,
            "agent_reasoning": output.reasoning,
            "confidence": output.confidence,
            "confidence_threshold": self.confidence_threshold,
            "checks": checks,
            "passed": passed,
            "escalated_to_human": escalated,
            "agent_timestamp": output.timestamp,
            "reconciler_timestamp": datetime.utcnow().isoformat(),
        }
