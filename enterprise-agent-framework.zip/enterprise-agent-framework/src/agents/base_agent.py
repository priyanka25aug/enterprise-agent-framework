from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
import uuid


@dataclass
class AgentInput:
    text: str
    metadata: dict = field(default_factory=dict)
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class AgentOutput:
    request_id: str
    agent_name: str
    output: Any
    confidence: float
    reasoning: str
    escalate_to_human: bool = False
    metadata: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id,
            "agent_name": self.agent_name,
            "output": self.output,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "escalate_to_human": self.escalate_to_human,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }


class BaseAgent(ABC):
    """
    Abstract base class for all specialist agents.

    All agents must implement:
      - process(): core logic, returns AgentOutput
      - can_handle(): returns True if this agent can handle the given input

    Agents should be single-responsibility. If you find yourself adding
    conditionals for different input types, split into two agents.
    """

    def __init__(self, name: str, llm_client=None):
        self.name = name
        self.llm = llm_client

    @abstractmethod
    def process(self, agent_input: AgentInput) -> AgentOutput:
        """Execute the agent's core logic and return a structured output."""
        pass

    @abstractmethod
    def can_handle(self, intent: str) -> bool:
        """Return True if this agent is the right handler for the given intent."""
        pass

    def _build_output(
        self,
        agent_input: AgentInput,
        output: Any,
        confidence: float,
        reasoning: str,
        escalate: bool = False,
        metadata: Optional[dict] = None,
    ) -> AgentOutput:
        return AgentOutput(
            request_id=agent_input.request_id,
            agent_name=self.name,
            output=output,
            confidence=confidence,
            reasoning=reasoning,
            escalate_to_human=escalate,
            metadata=metadata or {},
        )
