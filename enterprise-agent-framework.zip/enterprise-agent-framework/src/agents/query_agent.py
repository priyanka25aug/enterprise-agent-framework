from src.agents.base_agent import BaseAgent, AgentInput, AgentOutput


class QueryAgent(BaseAgent):
    """
    General-purpose Q&A agent. Acts as the default fallback agent.

    Handles open-ended questions that don't map to a specialist domain.
    Lower confidence ceiling than specialist agents by design — if a query
    should go to DocumentAgent or RiskAgent, the router should catch it first.
    """

    def __init__(self, llm_client=None):
        super().__init__(name="query_agent", llm_client=llm_client)

    def can_handle(self, intent: str) -> bool:
        return intent == "query"

    def process(self, agent_input: AgentInput) -> AgentOutput:
        if self.llm:
            answer = self.llm.complete(
                f"Answer the following question clearly and concisely:\n\n{agent_input.text}"
            )
            confidence = 0.80
        else:
            answer = f"[Mock] Query received: '{agent_input.text}'"
            confidence = 0.70

        return self._build_output(
            agent_input=agent_input,
            output={"answer": answer},
            confidence=confidence,
            reasoning="General query handled by fallback query agent.",
            escalate=False,
        )
