from src.agents.base_agent import BaseAgent, AgentInput, AgentOutput

RISK_PROMPT = """You are a specialist risk assessment agent working in a regulated financial environment.

Your job: identify and assess risk signals in the provided text.

Risk categories to assess:
- market_risk: exposure to price movements, volatility, currency
- credit_risk: counterparty exposure, default probability
- operational_risk: process failures, system issues, human error
- regulatory_risk: compliance breaches, reporting failures, limit breaches
- liquidity_risk: funding gaps, illiquid positions

For each identified risk, return:
- category: one of the above
- severity: low | medium | high | critical
- description: plain English description of the risk
- recommended_action: what should happen next

Also return:
- overall_severity: highest severity found across all risks
- confidence: 0.0 to 1.0
- requires_immediate_escalation: true if any critical risks found

Text to assess:
{text}

Respond in JSON only. No preamble."""


class RiskAgent(BaseAgent):
    """
    Specialist agent for risk identification and assessment.

    Flags market, credit, operational, regulatory and liquidity risks.
    Any critical severity finding automatically triggers escalation.
    """

    CRITICAL_KEYWORDS = [
        "breach", "limit exceeded", "margin call", "default",
        "regulatory action", "fca notice", "pra notice", "immediate"
    ]

    def __init__(self, llm_client=None):
        super().__init__(name="risk_agent", llm_client=llm_client)

    def can_handle(self, intent: str) -> bool:
        return intent == "risk"

    def process(self, agent_input: AgentInput) -> AgentOutput:
        # Fast pre-check: scan for critical keywords before LLM call
        critical_hit = self._check_critical_keywords(agent_input.text)

        if self.llm:
            result = self._process_with_llm(agent_input)
        else:
            result = self._process_mock(agent_input, critical_hit)

        confidence = result.get("confidence", 0.5)
        requires_escalation = (
            result.get("requires_immediate_escalation", False)
            or critical_hit
            or confidence < 0.65
        )

        return self._build_output(
            agent_input=agent_input,
            output=result,
            confidence=confidence,
            reasoning=(
                f"Overall severity: {result.get('overall_severity', 'unknown')}. "
                f"{len(result.get('risks', []))} risk(s) identified. "
                + ("IMMEDIATE ESCALATION REQUIRED." if requires_escalation else "Routine review.")
            ),
            escalate=requires_escalation,
            metadata={
                "overall_severity": result.get("overall_severity"),
                "risk_count": len(result.get("risks", [])),
                "critical_keyword_hit": critical_hit,
            },
        )

    def _check_critical_keywords(self, text: str) -> bool:
        text_lower = text.lower()
        return any(kw in text_lower for kw in self.CRITICAL_KEYWORDS)

    def _process_with_llm(self, agent_input: AgentInput) -> dict:
        import json
        prompt = RISK_PROMPT.format(text=agent_input.text)
        response = self.llm.complete(prompt)
        return json.loads(response)

    def _process_mock(self, agent_input: AgentInput, critical_hit: bool) -> dict:
        text = agent_input.text.lower()
        risks = []

        if "exposure" in text or "market" in text:
            risks.append({
                "category": "market_risk",
                "severity": "high" if critical_hit else "medium",
                "description": "[Mock] Potential market exposure identified.",
                "recommended_action": "Review position limits with desk head.",
            })

        if "counterparty" in text or "credit" in text:
            risks.append({
                "category": "credit_risk",
                "severity": "medium",
                "description": "[Mock] Counterparty exposure flagged.",
                "recommended_action": "Verify credit limits with credit risk team.",
            })

        severity_order = ["low", "medium", "high", "critical"]
        severities = [r["severity"] for r in risks] or ["low"]
        overall = max(severities, key=lambda s: severity_order.index(s))

        return {
            "risks": risks,
            "overall_severity": overall,
            "requires_immediate_escalation": critical_hit or overall == "critical",
            "confidence": 0.78 if risks else 0.55,
        }
