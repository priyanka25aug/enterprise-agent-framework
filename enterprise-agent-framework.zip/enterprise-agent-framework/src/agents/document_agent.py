from src.agents.base_agent import BaseAgent, AgentInput, AgentOutput

DOCUMENT_PROMPT = """You are a specialist document analysis agent working in a regulated financial environment.

Your job: classify the document type and extract key structured information.

Document types you handle:
- earnings_call: quarterly/annual earnings call transcripts
- risk_disclosure: risk sections from regulatory filings
- trade_confirmation: trade settlement documents
- compliance_report: internal compliance or audit reports
- unknown: anything that does not clearly fit the above

For each document, return:
1. document_type: one of the types above
2. key_entities: companies, people, dates, amounts mentioned
3. summary: 2-3 sentence plain English summary
4. risk_flags: any statements that may require Risk or Legal review
5. confidence: 0.0 to 1.0 — how confident you are in this classification

Be conservative. If you are not sure, say so. A low confidence score is more useful
than a confident wrong answer.

Document text:
{text}

Respond in JSON only. No preamble."""


class DocumentAgent(BaseAgent):
    """
    Specialist agent for document classification and extraction.

    Handles: earnings calls, risk disclosures, trade confirmations,
    compliance reports.

    Returns structured extraction with confidence scoring.
    If confidence < 0.6 or risk_flags are present, sets escalate_to_human=True.
    """

    def __init__(self, llm_client=None):
        super().__init__(name="document_agent", llm_client=llm_client)

    def can_handle(self, intent: str) -> bool:
        return intent == "document"

    def process(self, agent_input: AgentInput) -> AgentOutput:
        if self.llm:
            result = self._process_with_llm(agent_input)
        else:
            result = self._process_mock(agent_input)

        confidence = result.get("confidence", 0.5)
        has_risk_flags = bool(result.get("risk_flags"))
        escalate = confidence < 0.6 or has_risk_flags

        return self._build_output(
            agent_input=agent_input,
            output=result,
            confidence=confidence,
            reasoning=(
                f"Classified as '{result.get('document_type', 'unknown')}' "
                f"with confidence {confidence:.2f}. "
                + ("Risk flags found — escalating." if has_risk_flags else "No risk flags.")
            ),
            escalate=escalate,
            metadata={"document_type": result.get("document_type")},
        )

    def _process_with_llm(self, agent_input: AgentInput) -> dict:
        import json
        prompt = DOCUMENT_PROMPT.format(text=agent_input.text)
        response = self.llm.complete(prompt)
        return json.loads(response)

    def _process_mock(self, agent_input: AgentInput) -> dict:
        """
        Deterministic mock for testing without an LLM.
        Returns a plausible structure based on keyword presence.
        """
        text = agent_input.text.lower()
        if "earnings" in text or "revenue" in text or "quarter" in text:
            doc_type = "earnings_call"
            confidence = 0.88
        elif "risk" in text or "disclosure" in text or "exposure" in text:
            doc_type = "risk_disclosure"
            confidence = 0.82
        elif "trade" in text or "settlement" in text or "confirmation" in text:
            doc_type = "trade_confirmation"
            confidence = 0.91
        elif "compliance" in text or "audit" in text:
            doc_type = "compliance_report"
            confidence = 0.79
        else:
            doc_type = "unknown"
            confidence = 0.40

        return {
            "document_type": doc_type,
            "key_entities": [],
            "summary": f"[Mock] Document classified as {doc_type}.",
            "risk_flags": [],
            "confidence": confidence,
        }
