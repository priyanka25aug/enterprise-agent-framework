import re
from typing import Dict, Optional
from src.agents.base_agent import BaseAgent, AgentInput, AgentOutput


# Keyword-based intent rules — fast, auditable, no LLM call needed for routing.
# In production you can replace or augment this with an LLM classifier.
INTENT_RULES: Dict[str, list] = {
    "document": [
        "classify", "extract", "document", "filing", "report",
        "earnings", "disclosure", "parse", "read", "summarise", "summarize"
    ],
    "risk": [
        "risk", "flag", "alert", "threshold", "breach", "compliance",
        "exposure", "limit", "regulatory", "pnl", "loss"
    ],
    "query": [
        "what", "how", "why", "when", "who", "explain",
        "tell me", "show me", "list", "compare"
    ],
}


class IntentRouter:
    """
    Routes incoming requests to the appropriate specialist agent.

    Uses a two-pass approach:
    1. Keyword matching against INTENT_RULES (fast, deterministic)
    2. Falls back to a registered default agent if no match found

    Keeps routing logic entirely separate from agent execution.
    This makes the system debuggable — you can always trace why a
    request went to a particular agent.
    """

    def __init__(self, default_agent_name: Optional[str] = "query"):
        self._agents: Dict[str, BaseAgent] = {}
        self._default = default_agent_name

    def register(self, intent: str, agent: BaseAgent) -> None:
        """Register a specialist agent for a given intent label."""
        self._agents[intent] = agent

    def route(self, agent_input: AgentInput) -> AgentOutput:
        """
        Classify the input intent and dispatch to the right agent.
        Returns the agent's AgentOutput directly.
        """
        intent = self._classify(agent_input.text)
        agent = self._agents.get(intent) or self._agents.get(self._default)

        if agent is None:
            raise ValueError(
                f"No agent registered for intent '{intent}' and no default set. "
                f"Registered agents: {list(self._agents.keys())}"
            )

        return agent.process(agent_input)

    def _classify(self, text: str) -> str:
        text_lower = text.lower()
        scores: Dict[str, int] = {intent: 0 for intent in INTENT_RULES}

        for intent, keywords in INTENT_RULES.items():
            for kw in keywords:
                if re.search(rf"\b{re.escape(kw)}\b", text_lower):
                    scores[intent] += 1

        best_intent = max(scores, key=lambda k: scores[k])

        # If no keywords matched at all, fall back to default
        if scores[best_intent] == 0:
            return self._default or "query"

        return best_intent

    def explain_routing(self, text: str) -> dict:
        """
        Returns the routing decision with scores — useful for debugging
        and satisfying audit requirements.
        """
        text_lower = text.lower()
        scores: Dict[str, int] = {intent: 0 for intent in INTENT_RULES}
        matched_keywords: Dict[str, list] = {intent: [] for intent in INTENT_RULES}

        for intent, keywords in INTENT_RULES.items():
            for kw in keywords:
                if re.search(rf"\b{re.escape(kw)}\b", text_lower):
                    scores[intent] += 1
                    matched_keywords[intent].append(kw)

        selected = max(scores, key=lambda k: scores[k])
        return {
            "selected_intent": selected,
            "scores": scores,
            "matched_keywords": matched_keywords,
        }
