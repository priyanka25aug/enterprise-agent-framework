import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    level=logging.INFO,
)


class AuditLogger:
    """
    Structured audit trail for every agent decision.

    Writes to:
    - stdout (via Python logging)
    - a local JSONL file (one JSON object per line, append mode)

    In production, replace or extend _write_to_file() with your
    preferred sink: BigQuery, Splunk, CloudWatch, etc.

    Every log entry is immutable once written. Do not modify existing entries.
    """

    def __init__(self, log_dir: Optional[str] = None):
        self._logger = logging.getLogger("audit")
        self._log_dir = log_dir or os.getenv("AUDIT_LOG_DIR", "./logs")
        Path(self._log_dir).mkdir(parents=True, exist_ok=True)
        self._log_file = Path(self._log_dir) / f"audit_{datetime.utcnow().strftime('%Y%m%d')}.jsonl"

    def log(self, entry: dict) -> None:
        """Write an audit entry. Safe to call from multiple threads."""
        enriched = {**entry, "logged_at": datetime.utcnow().isoformat()}
        self._logger.info(json.dumps(enriched))
        self._write_to_file(enriched)

    def _write_to_file(self, entry: dict) -> None:
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except OSError as e:
            self._logger.error(f"Failed to write audit log: {e}")

    def tail(self, n: int = 10) -> list:
        """Return the last n audit entries from today's log file."""
        if not self._log_file.exists():
            return []
        lines = self._log_file.read_text(encoding="utf-8").strip().splitlines()
        return [json.loads(line) for line in lines[-n:]]
