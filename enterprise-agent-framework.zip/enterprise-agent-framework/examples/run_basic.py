"""
Basic example — runs three requests through the full pipeline:
  document classification, risk assessment, general query.

No LLM key needed — uses mock agents by default.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.agents import DocumentAgent, RiskAgent, QueryAgent
from src.agents.base_agent import AgentInput
from src.router.intent_router import IntentRouter
from src.reconciler.reconciler import Reconciler


def run(text: str, router: IntentRouter, reconciler: Reconciler) -> None:
    print(f"\n{'='*60}")
    print(f"INPUT: {text}")
    print(f"{'='*60}")

    routing_explanation = router.explain_routing(text)
    print(f"ROUTING → intent: '{routing_explanation['selected_intent']}' "
          f"(scores: {routing_explanation['scores']})")

    agent_input = AgentInput(text=text)
    agent_output = router.route(agent_input)
    result = reconciler.process(agent_output)

    print(f"AGENT:  {result.agent_name}")
    print(f"PASSED: {result.passed}  |  CONFIDENCE: {result.confidence:.2f}  |  ESCALATED: {result.escalated_to_human}")
    if result.output:
        print(f"OUTPUT: {result.output}")
    if result.rejection_reason:
        print(f"REASON: {result.rejection_reason}")


def main():
    router = IntentRouter(default_agent_name="query")
    router.register("document", DocumentAgent())
    router.register("risk", RiskAgent())
    router.register("query", QueryAgent())

    reconciler = Reconciler(confidence_threshold=0.75)

    examples = [
        "Classify this earnings call document and flag any risk disclosures.",
        "We have a counterparty credit exposure breach on the EM desk — limit exceeded.",
        "What is the difference between market risk and credit risk?",
    ]

    for text in examples:
        run(text, router, reconciler)

    print(f"\n{'='*60}")
    print("Audit trail (last 3 entries):")
    for entry in reconciler.logger.tail(3):
        print(f"  [{entry['reconciler_timestamp']}] {entry['agent_name']} → passed={entry['passed']}")


if __name__ == "__main__":
    main()
