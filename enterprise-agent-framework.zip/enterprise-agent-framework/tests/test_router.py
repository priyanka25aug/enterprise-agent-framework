import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.router.intent_router import IntentRouter
from src.agents import DocumentAgent, RiskAgent, QueryAgent
from src.agents.base_agent import AgentInput


@pytest.fixture
def router():
    r = IntentRouter(default_agent_name="query")
    r.register("document", DocumentAgent())
    r.register("risk", RiskAgent())
    r.register("query", QueryAgent())
    return r


def test_routes_document_intent(router):
    inp = AgentInput(text="Classify this earnings call document")
    result = router.route(inp)
    assert result.agent_name == "document_agent"


def test_routes_risk_intent(router):
    inp = AgentInput(text="Flag any risk exposure breaches on this position")
    result = router.route(inp)
    assert result.agent_name == "risk_agent"


def test_routes_query_intent(router):
    inp = AgentInput(text="What is the difference between VaR and CVaR?")
    result = router.route(inp)
    assert result.agent_name == "query_agent"


def test_explain_routing_returns_scores(router):
    explanation = router.explain_routing("classify this document")
    assert "selected_intent" in explanation
    assert "scores" in explanation
    assert explanation["selected_intent"] == "document"


def test_document_agent_confidence_above_zero():
    agent = DocumentAgent()
    inp = AgentInput(text="This is an earnings call for Q3 2024.")
    output = agent.process(inp)
    assert 0.0 <= output.confidence <= 1.0


def test_risk_agent_escalates_on_breach():
    agent = RiskAgent()
    inp = AgentInput(text="Limit exceeded on the EM credit desk — immediate action required.")
    output = agent.process(inp)
    assert output.escalate_to_human is True


def test_agent_output_has_request_id():
    agent = DocumentAgent()
    inp = AgentInput(text="Classify this compliance report.")
    output = agent.process(inp)
    assert output.request_id == inp.request_id
